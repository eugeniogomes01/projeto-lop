var x = 280
var y = 400
function setup() {
  createCanvas(600, 600);
}

function draw() {
  background(255)
  ellipse (300,120, 55 ,55)
   
  rect  (x,y,40,40)
  
  if (keyIsDown(LEFT_ARROW)){
    x-= 5;
  }
  if (keyIsDown(RIGHT_ARROW)) {
     x += 5;
    
}
  if (keyIsDown(UP_ARROW)) {
    y -= 5;
  }
  if (keyIsDown(DOWN_ARROW)) {
    y += 5;
  }
  //textos do jogo
  var vidas = 5
  var dif   = 1
  var ponts = 0  
fill('red')
text("vidas: "+vidas,10,10)
text("pontos:"+ponts,255,10)
text("difículdade: "+ dif,500,10)
 

}